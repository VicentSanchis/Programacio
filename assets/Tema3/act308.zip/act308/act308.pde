/*
 * Activitat 308. Nombres múltiples
 * Genera dos números aleatoris entre 0 i 100, identifica quin és el major
 * i quin el menor, i comprova si el major és múltiple del menor.
 */

int num1;
int num2;
int major;
int menor;
String missatgeResultat = "";

void setup() {
  size(680, 240);
  background(245);

  // Genera dos números enters aleatoris entre 0 i 100 (int(random(101)) dona valors de 0 a 100)
  num1 = int(random(101));
  num2 = int(random(101));

  // Determina quin número és el major i quin el menor
  if (num1 >= num2) {
    major = num1;
    menor = num2;
  } else {
    major = num2;
    menor = num1;
  }

  // Comprova si el major és múltiple del menor (evitant dividir per zero)
  if (menor == 0) {
    missatgeResultat = "El menor és 0: no es pot dividir per zero per comprovar si " + major + " n'és múltiple.";
  } else if (major % menor == 0) {
    int quocient = major / menor;
    missatgeResultat = major + " SÍ és múltiple de " + menor + " (" + quocient + " x " + menor + " = " + major + ").";
  } else {
    int residu = major % menor;
    missatgeResultat = major + " NO és múltiple de " + menor + " (residu = " + residu + ").";
  }

  println("=== ACTIVITAT 308: NOMBRES MÚLTIPLES ===");
  println("Números generats: " + num1 + " i " + num2);
  println("Major: " + major + " | Menor: " + menor);
  println(missatgeResultat);

  // Dibuixa els resultats al canvas amb la funció text()
  fill(25);
  textSize(18);
  text("Activitat 308 - Nombres múltiples", 25, 38);

  textSize(14);
  text("Números generats: " + num1 + " i " + num2 + "  (Major: " + major + ", Menor: " + menor + ")", 25, 82);

  fill(15, 80, 150);
  text(missatgeResultat, 25, 122, width - 50, 70);
}
