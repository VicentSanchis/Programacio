/**
 * -------------------------------------------------------------------
 * TÍTOL: Activitat 403 - Combinació de PVector i PImage
 * DESCRIPCIÓ: Programa que utilitza objectes PVector per controlar la 
 *            posició, la velocitat i el rebot d'una imatge (PImage) que 
 *            es mou de manera autònoma per la pantalla.
 * -------------------------------------------------------------------
 */

// 1. DECLARACIÓ D'OBJECTES PImage i PVector
PImage imatgeLogo;

// Vector per a la posició actual de la imatge
PVector posicio;

// Vector per gestionar la velocitat (desplaçament en X i Y)
PVector velocitat;

void setup() {
  size(800, 600);
  background(30);

  // 2. INSTANCIACIÓ DE LA CLASSE PImage
  // Carreguem la imatge des de la carpeta 'data' del projecte
  imatgeLogo = loadImage("logo.png");
  
  // 3. INSTANCIACIÓ DE LA CLASSE PVector
  // Inicialitzem la posició inicial al centre de la pantalla
  posicio = new PVector(width / 2, height / 2);
  
  // Inicialitzem la velocitat amb valors aleatoris per a X i Y
  velocitat = new PVector(3.5, 2.2);
}

void draw() {
  // Fons amb lleugera transparència per crear un efecte estètic de rastre
  background(30, 30, 30, 150);

  // 4. ACTUALITZACIÓ DE LA POSICIÓ MITJANCÀNÇANT VECTORS
  // Sumem el vector velocitat al vector posició (equivalent a posicio.x += velocitat.x)
  posicio.add(velocitat);

  // 5. GESTIÓ DE REBOTS ALS LÍMITS DE LA FINESTRA
  // Si la imatge arriba a les vores horitzontals, invertim la velocitat en X
  if (posicio.x < 0 || posicio.x > width - 100) {
    velocitat.x = velocitat.x * -1;
  }
  
  // Si la imatge arriba a les vores verticals, invertim la velocitat en Y
  if (posicio.y < 0 || posicio.y > height - 100) {
    velocitat.y = velocitat.y * -1;
  }

  // 6. DIBUIX DE LA IMATGE UTILITZANT LES COORDENADES DEL PVector
  // Pintem la imatge utilitzant posicio.x i posicio.y com a referència
  imageMode(CORNER);
  image(imatgeLogo, posicio.x, posicio.y, 100, 100);

  // Informació visual a la pantalla
  fill(255);
  textSize(14);
  text("Posició X: " + int(posicio.x) + " | Posició Y: " + int(posicio.y), 30, 40);
}
