// Variables globals
int suma = 0;
float mitjana = 0;
int maxim;
int minim;
int parells = 0;

// Estructures
int [] nombres;

void setup() {
  size(700, 320);
  background(245);

  nombres = new int [20];  // 1. Declaració i creació de l'arrai de 20 enters

  // 2. Inicialització element a element amb valors entre 0 i 100
  // random(101) retorna un float entre 0.0 i 100.999...; int() trunca a 0..100
  for (int i = 0; i < nombres.length; i++) 
    nombres[i] = int(random(101));

  // 3. Inicialitzem màxim i mínim amb el primer element de l'arrai
  maxim = nombres[0];
  minim = nombres[0];

  // 4. Recorregut per calcular les estadístiques
  for (int i = 0; i < nombres.length; i++) {
    int valor = nombres[i];
    suma += valor;

    if (valor > maxim) 
      maxim = valor;
    
    if (valor < minim) 
      minim = valor;
    
    if (valor % 2 == 0) 
      parells++;
  }

  mitjana = (float) suma / nombres.length;

  // 5. Mostra per consola
  println("Arrai (" + nombres.length + " elements):");
  for (int i = 0; i < nombres.length; i++) {
    print(nombres[i]);
    if (i < nombres.length - 1) 
      print(", ");
    
  }
  println();
  println("Suma: " + suma);
  println("Mitjana: " + nf(mitjana, 1, 2));
  println("Màxim: " + maxim);
  println("Mínim: " + minim);
  println("Quantitat de nombres parells: " + parells);

  // 6. Mostra visual per pantalla (canvas)
  fill(20);
  textSize(16);
  text("Activitat 501 - Estadístiques de l'arrai (0..100)", 25, 35);

  textSize(13);
  String textArrai = "Arrai: ";
  for (int i = 0; i < nombres.length; i++) 
    textArrai += nombres[i] + (i < nombres.length - 1 ? " | " : "");
  
  text(textArrai, 25, 70, width - 50, 60);

  textSize(15);
  text("Suma: " + suma, 25, 150);
  text("Mitjana: " + nf(mitjana, 1, 2), 25, 180);
  text("Valor màxim: " + maxim, 25, 210);
  text("Valor mínim: " + minim, 25, 240);
  text("Nombres parells: " + parells, 25, 270);
}
