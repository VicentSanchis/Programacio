/*
 * Activitat 502. Arrai de caràcters i traça de recorreguts
 *
 * CONCLUSIONS SOBRE ELS LÍMITS D'UN ARRAI I ArrayIndexOutOfBoundsException:
 * - Un arrai de longitud N té índexs vàlids des de 0 fins a N - 1. Si intentem
 *   accedir a array[-1] o a array[array.length], Java/Processing llançarà una
 *   excepció ArrayIndexOutOfBoundsException i el programa s'aturarà.
 * - Per evitar-ho, la condició de continuació del bucle for ha d'utilitzar
 *   sempre el límit estricte "i < array.length" (mai "<=" amb length).
 * - Quan la variable de control arriba a valdre array.length, la condició
 *   "i < array.length" passa a ser falsa, el bucle finalitza de manera segura
 *   i no es realitza cap accés fora de rang.
 */

int[] enters = {12, 25, 8, 41, 19, 33, 7, 50, 14, 28};
char[] lletres = {'D', 'A', 'W', '0', '5'};

void setup() {
  size(680, 260);
  background(245);

  // 1. Visualització i traça de l'arrai d'enters (10 elements)
  println("=== TRAÇA ARRAI D'ENTERS (longitud = " + enters.length + ") ===");
  print("Enters: ");
  for (int i = 0; i < enters.length; i++) {
    int seguentI = i + 1;
    boolean continua = seguentI < enters.length;

    println("Iteració " + i +
            " | i = " + i +
            " | enters[" + i + "] = " + enters[i] +
            " | proper índex = " + seguentI +
            " (" + seguentI + " < " + enters.length + " -> " + continua + ")");

    print(enters[i]);
    if (i < enters.length - 1) {
      print(", ");
    }
  }
  println();
  println("Fi del recorregut d'enters: la condició i < " + enters.length + " deixa de complir-se.");
  println();

  // 2. Visualització i traça de l'arrai de caràcters (5 elements)
  println("=== TRAÇA ARRAI DE CARÀCTERS (longitud = " + lletres.length + ") ===");
  print("Caràcters: ");
  for (int i = 0; i < lletres.length; i++) {
    int seguentI = i + 1;
    boolean continua = seguentI < lletres.length;

    println("Iteració " + i +
            " | i = " + i +
            " | lletres[" + i + "] = '" + lletres[i] + "'" +
            " | proper índex = " + seguentI +
            " (" + seguentI + " < " + lletres.length + " -> " + continua + ")");

    print("'" + lletres[i] + "'");
    if (i < lletres.length - 1) {
      print(" - ");
    }
  }
  println();
  println("Fi del recorregut de caràcters: la condició i < " + lletres.length + " deixa de complir-se.");

  // 3. Representació visual al canvas
  fill(25);
  textSize(16);
  text("Activitat 502 - Visualització d'arrais", 25, 35);

  textSize(14);
  String textEnters = "Arrai d'enters (" + enters.length + "): ";
  for (int i = 0; i < enters.length; i++) {
    textEnters += enters[i] + (i < enters.length - 1 ? "  " : "");
  }
  text(textEnters, 25, 85);

  String textLletres = "Arrai de caràcters (" + lletres.length + "): ";
  for (int i = 0; i < lletres.length; i++) {
    textLletres += "'" + lletres[i] + "'" + (i < lletres.length - 1 ? "  " : "");
  }
  text(textLletres, 25, 130);

  fill(80);
  textSize(12);
  text("Consulta la consola per veure la traça completa pas a pas i la condició de sortida del bucle.", 25, 190);
}
