/*
 * Activitat 503. El joc del penjat amb arrais de caràcters
 * Es gestiona la paraula secreta, l'estat actual endevinat, les lletres
 * provades i els intents restants mitjançant arrais de tipus char.
 */

String[] llistatParaules = {"PROGRAMACIO", "MATRIU", "COLECCIO", "OBJECTE", "ARRAI"};
String paraulaSecreta;

char[] lletresSecretes;
char[] estatParaula;
char[] lletresProvades = new char[26];
int numProvades = 0;

int intentsMaxims = 6;
int errors = 0;
boolean guanyat = false;
boolean perdut = false;

void setup() {
  size(640, 420);
  textAlign(LEFT, BASELINE);

  // Tria una paraula aleatòria del llistat i crea els arrais de caràcters
  int indexParaula = int(random(llistatParaules.length));
  paraulaSecreta = llistatParaules[indexParaula];

  lletresSecretes = new char[paraulaSecreta.length()];
  estatParaula = new char[paraulaSecreta.length()];

  for (int i = 0; i < paraulaSecreta.length(); i++) {
    lletresSecretes[i] = paraulaSecreta.charAt(i);
    estatParaula[i] = '_';
  }

  println("Joc iniciat! Lletres de la paraula: " + lletresSecretes.length);
}

void draw() {
  background(245);

  // Títol
  fill(25);
  textSize(24);
  text("Activitat 503 - El joc del penjat", 30, 45);

  // Dibuix simple del suport i errors acumulats
  stroke(40);
  strokeWeight(4);
  line(440, 260, 560, 260); // base
  line(500, 260, 500, 90);  // pal vertical
  line(500, 90, 565, 90);   // travesser
  line(565, 90, 565, 115);  // corda

  noFill();
  stroke(180, 30, 30);
  strokeWeight(3);
  if (errors >= 1) ellipse(565, 135, 40, 40);               // cap
  if (errors >= 2) line(565, 155, 565, 210);                  // cos
  if (errors >= 3) line(565, 170, 535, 195);                  // braç esquerre
  if (errors >= 4) line(565, 170, 595, 195);                  // braç dret
  if (errors >= 5) line(565, 210, 540, 245);                  // cama esquerra
  if (errors >= 6) line(565, 210, 590, 245);                  // cama dreta

  // Estat de la paraula (amb espais entre caràcters per llegir-la millor)
  fill(15);
  textSize(32);
  String textEstat = "";
  for (int i = 0; i < estatParaula.length; i++) {
    textEstat += estatParaula[i] + " ";
  }
  text(textEstat, 30, 130);

  // Informació d'intents restants
  textSize(16);
  int restants = intentsMaxims - errors;
  text("Intents restants: " + restants + " / " + intentsMaxims, 30, 180);

  // Lletres ja provades
  String textProvades = "Lletres provades: ";
  for (int i = 0; i < numProvades; i++) {
    textProvades += lletresProvades[i];
    if (i < numProvades - 1) {
      textProvades += ", ";
    }
  }
  text(textProvades, 30, 220, 380, 70);

  // Missatge d'estat final o instruccions
  textSize(15);
  if (guanyat) {
    fill(20, 130, 50);
    text("Has guanyat! Prem 'R' o 'r' per tornar a jugar.", 30, 330);
  } else if (perdut) {
    fill(180, 30, 30);
    text("Has perdut! La paraula era: " + paraulaSecreta, 30, 325);
    text("Prem 'R' o 'r' per tornar a jugar.", 30, 355);
  } else {
    fill(80);
    text("Escriu una lletra del teclat per provar.", 30, 330);
  }
}

void keyPressed() {
  // Reinici ràpid quan la partida ha acabat
  if ((guanyat || perdut) && (key == 'r' || key == 'R')) {
    errors = 0;
    numProvades = 0;
    guanyat = false;
    perdut = false;
    setup();
    return;
  }

  if (guanyat || perdut) {
    return;
  }

  char lletra = Character.toUpperCase(key);
  if (lletra < 'A' || lletra > 'Z') {
    return;
  }

  // Comprova si la lletra ja s'havia provat
  boolean jaProvada = false;
  for (int i = 0; i < numProvades; i++) {
    if (lletresProvades[i] == lletra) {
      jaProvada = true;
      break;
    }
  }

  if (jaProvada) {
    println("Ja has provat la lletra '" + lletra + "'.");
    return;
  }

  // Guarda la nova lletra dins l'arrai de provades
  lletresProvades[numProvades] = lletra;
  numProvades++;

  // Comprova si la lletra apareix a la paraula secreta
  boolean encert = false;
  for (int i = 0; i < lletresSecretes.length; i++) {
    if (lletresSecretes[i] == lletra) {
      estatParaula[i] = lletra;
      encert = true;
    }
  }

  if (!encert) {
    errors++;
    println("Error! La lletra '" + lletra + "' no és a la paraula. Errors: " + errors);
  } else {
    println("Encert! La lletra '" + lletra + "' hi és.");
  }

  // Comprova si queden guions baixos
  boolean quedenLletres = false;
  for (int i = 0; i < estatParaula.length; i++) {
    if (estatParaula[i] == '_') {
      quedenLletres = true;
      break;
    }
  }

  if (!quedenLletres) {
    guanyat = true;
  } else if (errors >= intentsMaxims) {
    perdut = true;
    // Descobreix la paraula secreta en perdre
    for (int i = 0; i < lletresSecretes.length; i++) {
      estatParaula[i] = lletresSecretes[i];
    }
  }
}
