/*
 * Activitat 504. Representació gràfica, estadístiques i anàlisi de matrius 2D
 *
 * CONCLUSIONS SOBRE EL RECORREGUT DE MATRIUS AMB BUCLES IMBRICATS:
 * - Una matriu bidimensional s'organitza en files (primer índex, i) i columnes
 *   (segon índex, j). Per recórrer-la per files, el bucle exterior controla les
 *   files (0 fins a matriu.length - 1) i l'interior recorre les columnes
 *   (0 fins a matriu[i].length - 1) a cada fila.
 * - Per cada iteració del bucle exterior (una fila), el bucle interior completa
 *   totes les seues iteracions abans que l'índex i augmente en 1.
 * - Cal respectar sempre el límit estricte "< length" en ambdós nivells per
 *   evitar errors ArrayIndexOutOfBoundsException.
 */

int files = 5;
int columnes = 5;
int[][] matriu;

int sumaTotal = 0;
int maxim;
int comptadorParells = 0;
int[] sumaColumnes;

void setup() {
  size(720, 480);
  background(245);

  // 1. Creació i inicialització de la matriu 2D (5x5) amb valors entre 0 i 50
  matriu = new int[files][columnes];
  sumaColumnes = new int[columnes];

  for (int i = 0; i < matriu.length; i++) {
    for (int j = 0; j < matriu[i].length; j++) {
      matriu[i][j] = int(random(51));
    }
  }

  // Inicialitzem el màxim amb el primer element de la matriu
  maxim = matriu[0][0];

  // 2. Recorregut, traça per consola i càlcul d'estadístiques + suma de columnes
  println("=== TRAÇA DEL RECORREGUT DE LA MATRIU (" + files + "x" + columnes + ") ===");
  for (int i = 0; i < matriu.length; i++) {
    for (int j = 0; j < matriu[i].length; j++) {
      int valor = matriu[i][j];

      println("Fila i = " + i +
              ", Columna j = " + j +
              " -> matriu[" + i + "][" + j + "] = " + valor);

      sumaTotal += valor;
      sumaColumnes[j] += valor;

      if (valor > maxim) {
        maxim = valor;
      }
      if (valor % 2 == 0) {
        comptadorParells++;
      }
    }
    println("--- Fi de la fila i = " + i + " (i < " + matriu.length + ") ---");
  }
  println("Fi del recorregut complet de la matriu.");
  println();

  // Resum per consola
  println("=== ESTADÍSTIQUES ===");
  println("Suma total: " + sumaTotal);
  println("Valor màxim: " + maxim);
  println("Quantitat de nombres parells: " + comptadorParells);
  for (int j = 0; j < sumaColumnes.length; j++) {
    println("Suma columna " + j + ": " + sumaColumnes[j]);
  }

  // 3. Representació gràfica de la matriu i resultats al canvas
  fill(25);
  textSize(18);
  text("Activitat 504 - Matriu 2D i Estadístiques", 25, 35);

  int midaCella = 54;
  int margeX = 25;
  int margeY = 60;

  for (int i = 0; i < matriu.length; i++) {
    for (int j = 0; j < matriu[i].length; j++) {
      int x = margeX + j * midaCella;
      int y = margeY + i * midaCella;
      int valor = matriu[i][j];

      // Color segons el valor i si és parell o senar
      if (valor == maxim) {
        fill(255, 210, 90); // destacat per al màxim
      } else if (valor % 2 == 0) {
        fill(180, 215, 250); // blau suau per als parells
      } else {
        fill(225, 235, 225); // verd/gris suau per als senars
      }

      stroke(60);
      strokeWeight(1.5);
      rect(x, y, midaCella - 4, midaCella - 4, 6);

      fill(20);
      textAlign(CENTER, CENTER);
      textSize(15);
      text(valor, x + (midaCella - 4) / 2, y + (midaCella - 4) / 2);
    }
  }

  // Mostra el resum estadístic i la suma de columnes a la dreta
  textAlign(LEFT, BASELINE);
  int infoX = margeX + files * midaCella + 35;
  int infoY = 80;

  fill(25);
  textSize(15);
  text("Suma total: " + sumaTotal, infoX, infoY);
  text("Valor màxim: " + maxim, infoX, infoY + 28);
  text("Nombres parells: " + comptadorParells, infoX, infoY + 56);

  text("Suma per columnes:", infoX, infoY + 96);
  textSize(13);
  for (int j = 0; j < sumaColumnes.length; j++) {
    text("• Columna " + j + ": " + sumaColumnes[j], infoX + 10, infoY + 122 + j * 22);
  }
}
