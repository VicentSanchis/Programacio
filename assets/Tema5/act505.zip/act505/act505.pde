/*
 * Activitat 505. Un sudoku simple (matriu 9x9)
 * Genera un tauler vàlid de Sudoku, oculta algunes cel·les per completar,
 * permet seleccionar cel·les buides amb el ratolí i validar números de l'1 al 9
 * comprovant files, columnes i submatrius 3x3.
 */

int mida = 9;
int[][] solucio = new int[mida][mida];
int[][] tauler = new int[mida][mida];
boolean[][] fixa = new boolean[mida][mida];
boolean[][] errorCella = new boolean[mida][mida];

int filaSel = -1;
int colSel = -1;
String missatge = "Fes clic en una cel·la buida i prem un número de l'1 al 9.";

void setup() {
  size(540, 600);
  textAlign(CENTER, CENTER);

  // 1. Primera fase: generació base de la matriu 9x9
  for (int fil = 0; fil < 9; fil++) {
    for (int col = 0; col < 9; col++) {
      if (fil == 0 || fil == 3 || fil == 6) {
        solucio[fil][col] = (col + fil / 3) % 9 + 1;
      } else {
        solucio[fil][col] = (solucio[(fil / 3) * 3][col] + 3 * fil - 1) % 9 + 1;
      }
    }
  }

  // 2. Segona fase: barallem files dins de cada banda de 3
  for (int fil = 0; fil < 9; fil += 3) {
    int f1, f2;
    do {
      f1 = int(random(fil, fil + 3));
      f2 = int(random(fil, fil + 3));
    } while (f1 == f2);

    for (int col = 0; col < 9; col++) {
      int aux = solucio[f1][col];
      solucio[f1][col] = solucio[f2][col];
      solucio[f2][col] = aux;
    }
  }

  // 3. Tercera fase: barallem columnes dins de cada franja de 3
  for (int col = 0; col < 9; col += 3) {
    int c1, c2;
    do {
      c1 = int(random(col, col + 3));
      c2 = int(random(col, col + 3));
    } while (c1 == c2);

    for (int fil = 0; fil < 9; fil++) {
      int aux = solucio[fil][c1];
      solucio[fil][c1] = solucio[fil][c2];
      solucio[fil][c2] = aux;
    }
  }

  // 4. Quarta fase: intercanviem dues files de submatrius (franges de 3 files)
  int sm1, sm2;
  do {
    sm1 = int(random(0, 3));
    sm2 = int(random(0, 3));
  } while (sm1 == sm2);

  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 9; j++) {
      int val1 = 3 * sm1 + i;
      int val2 = 3 * sm2 + i;
      int aux = solucio[val1][j];
      solucio[val1][j] = solucio[val2][j];
      solucio[val2][j] = aux;
    }
  }

  // 5. Preparem el tauler de joc ocultant aproximadament la meitat de les cel·les
  for (int i = 0; i < mida; i++) {
    for (int j = 0; j < mida; j++) {
      if (random(1) < 0.5) {
        tauler[i][j] = solucio[i][j];
        fixa[i][j] = true;
      } else {
        tauler[i][j] = 0;
        fixa[i][j] = false;
      }
      errorCella[i][j] = false;
    }
  }
}

void draw() {
  background(245);

  fill(25);
  textSize(20);
  text("Activitat 505 - Sudoku Simple (9x9)", width / 2, 28);

  int margeX = 45;
  int margeY = 55;
  int midaCella = 50;

  // Dibuix de les 81 cel·les de la matriu 9x9
  for (int i = 0; i < mida; i++) {
    for (int j = 0; j < mida; j++) {
      int x = margeX + j * midaCella;
      int y = margeY + i * midaCella;

      if (i == filaSel && j == colSel) {
        fill(205, 228, 255); // cel·la seleccionada
      } else if (errorCella[i][j]) {
        fill(255, 205, 205); // conflicte detectat
      } else if (fixa[i][j]) {
        fill(232, 235, 240); // pista inicial fixa
      } else {
        fill(255);           // cel·la editable
      }

      stroke(140);
      strokeWeight(1);
      rect(x, y, midaCella, midaCella);

      if (tauler[i][j] != 0) {
        if (errorCella[i][j]) {
          fill(185, 25, 25);
        } else if (fixa[i][j]) {
          fill(30);
        } else {
          fill(15, 95, 180);
        }
        textSize(20);
        text(tauler[i][j], x + midaCella / 2, y + midaCella / 2);
      }
    }
  }

  // Línies gruixudes per separar les 9 submatrius de 3x3
  stroke(35);
  strokeWeight(3);
  for (int k = 0; k <= 9; k += 3) {
    line(margeX + k * midaCella, margeY, margeX + k * midaCella, margeY + 9 * midaCella);
    line(margeX, margeY + k * midaCella, margeX + 9 * midaCella, margeY + k * midaCella);
  }

  // Comprovació de si el tauler està complet i sense errors
  boolean complet = true;
  boolean hiHaErrors = false;
  for (int i = 0; i < mida; i++) {
    for (int j = 0; j < mida; j++) {
      if (tauler[i][j] == 0) {
        complet = false;
      }
      if (errorCella[i][j]) {
        hiHaErrors = true;
      }
    }
  }

  fill(25);
  textSize(14);
  if (complet && !hiHaErrors) {
    fill(20, 130, 50);
    text("Enhorabona! Has completat el Sudoku correctament.", width / 2, 535);
  } else {
    text(missatge, width / 2, 535);
  }

  fill(90);
  textSize(12);
  text("Tecles 1-9: posar número | SUPR / ESBORRAR: buidar cel·la | R: nou tauler", width / 2, 568);
}

void mousePressed() {
  int margeX = 45;
  int margeY = 55;
  int midaCella = 50;

  if (mouseX >= margeX && mouseX < margeX + 9 * midaCella &&
      mouseY >= margeY && mouseY < margeY + 9 * midaCella) {
    colSel = (mouseX - margeX) / midaCella;
    filaSel = (mouseY - margeY) / midaCella;

    if (fixa[filaSel][colSel]) {
      missatge = "Aquesta cel·la és fixa i no es pot modificar.";
    } else {
      missatge = "Cel·la seleccionada (" + (filaSel + 1) + ", " + (colSel + 1) + "). Escriu un valor de l'1 al 9.";
    }
  }
}

void keyPressed() {
  if (key == 'r' || key == 'R') {
    filaSel = -1;
    colSel = -1;
    missatge = "Fes clic en una cel·la buida i prem un número de l'1 al 9.";
    setup();
    return;
  }

  if (filaSel == -1 || colSel == -1 || fixa[filaSel][colSel]) {
    return;
  }

  if (key >= '1' && key <= '9') {
    int num = key - '0';
    tauler[filaSel][colSel] = num;

    // Revalidem totes les cel·les no fixes segons fila, columna i submatriu 3x3
    for (int i = 0; i < mida; i++) {
      for (int j = 0; j < mida; j++) {
        errorCella[i][j] = false;
      }
    }

    for (int i = 0; i < mida; i++) {
      for (int j = 0; j < mida; j++) {
        int val = tauler[i][j];
        if (val != 0) {
          boolean repetit = false;

          // Comprova la fila i i la columna j
          for (int k = 0; k < mida; k++) {
            if (k != j && tauler[i][k] == val) {
              repetit = true;
            }
            if (k != i && tauler[k][j] == val) {
              repetit = true;
            }
          }

          // Comprova la submatriu 3x3 corresponent
          int iniciFil = (i / 3) * 3;
          int iniciCol = (j / 3) * 3;
          for (int r = iniciFil; r < iniciFil + 3; r++) {
            for (int c = iniciCol; c < iniciCol + 3; c++) {
              if ((r != i || c != j) && tauler[r][c] == val) {
                repetit = true;
              }
            }
          }

          if (repetit) {
            errorCella[i][j] = true;
          }
        }
      }
    }

    if (errorCella[filaSel][colSel]) {
      missatge = "El número " + num + " es repeteix en la fila, columna o submatriu 3x3.";
    } else {
      missatge = "Número " + num + " col·locat vàlidament.";
    }
  } else if (key == BACKSPACE || key == DELETE) {
    tauler[filaSel][colSel] = 0;
    errorCella[filaSel][colSel] = false;
    missatge = "Cel·la buidada.";
  }
}
