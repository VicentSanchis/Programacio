
/*
 * Activitat 507. Gestor de tasques amb ArrayList
 * Permet afegir, mostrar, consultar, eliminar i buidar tasques d'una llista
 * dinàmica utilitzant les operacions bàsiques d'ArrayList en Processing IDE.
 */

import java.util.ArrayList;

ArrayList<String> tasques;
String missatge = "Tecles: [1] Afegir prova | [2] Mostrar | [3] Consultar pos. 0 | [4] Eliminar pos. 0 | [5] Esborrar tot";

void setup() {
  size(720, 380);
  tasques = new ArrayList<String>();

  // Tasques inicials d'exemple
  tasques.add("Preparar presentació del Tema 5");
  tasques.add("Revisar exercicis d'ArrayList");
  tasques.add("Provar el codi en Processing IDE");

  println("=== GESTOR DE TASQUES INICIAT ===");
  println("Total de tasques inicials: " + tasques.size());
  for (int i = 0; i < tasques.size(); i++) {
    println("  [" + i + "] " + tasques.get(i));
  }
  println(missatge);
}

void draw() {
  background(245);

  fill(25);
  textSize(20);
  text("Activitat 507 - Gestor de tasques (ArrayList)", 25, 38);

  textSize(14);
  fill(60);
  text("Nombre de tasques actuals: " + tasques.size(), 25, 68);

  // Mostra la llista de tasques
  fill(20);
  textSize(15);
  if (tasques.isEmpty()) {
    fill(160, 40, 40);
    text("La llista de tasques està buida.", 25, 110);
  } else {
    for (int i = 0; i < tasques.size(); i++) {
      text((i + 1) + ". " + tasques.get(i), 35, 110 + i * 26);
    }
  }

  // Missatge d'estat i dreceres ràpides per consola/teclat
  int baseY = 250;
  fill(35);
  textSize(13);
  text("Estat: " + missatge, 25, baseY);

  fill(85);
  textSize(12);
  text("Dreceres: [A] Afegeix tasca | [L] Llista per consola | [E] Elimina la primera | [C] Buida la llista", 25, baseY + 35);
  text("Nota: També pots afegir una tasca escrivint text i prement ENTER.", 25, baseY + 58);
}

String textEscrit = "";

void keyPressed() {
  // Accions ràpides quan no s'està escrivint una nova tasca
  if (key == 'a' || key == 'A') {
    String nova = "Nova tasca #" + (tasques.size() + 1);
    tasques.add(nova);
    missatge = "S'ha afegit: \"" + nova + "\"";
    println(missatge);
    return;
  }

  if (key == 'l' || key == 'L') {
    println("--- LLISTAT DE TASQUES (" + tasques.size() + ") ---");
    if (tasques.isEmpty()) {
      println("No hi ha cap tasca pendent.");
    } else {
      for (int i = 0; i < tasques.size(); i++) {
        println(i + ": " + tasques.get(i));
      }
    }
    missatge = "Llistat mostrat per consola.";
    return;
  }

  if (key == 'e' || key == 'E') {
    if (tasques.isEmpty()) {
      missatge = "No es pot eliminar cap tasca: la llista està buida.";
    } else {
      String eliminada = tasques.remove(0);
      missatge = "Tasca eliminada: \"" + eliminada + "\"";
    }
    println(missatge);
    return;
  }

  if (key == 'c' || key == 'C') {
    tasques.clear();
    missatge = "S'han esborrat totes les tasques.";
    println(missatge);
    return;
  }

  // Entrada de text lliure per afegir una tasca amb ENTER
  if (key == ENTER || key == RETURN) {
    String neta = textEscrit.trim();
    if (neta.length() > 0) {
      tasques.add(neta);
      missatge = "Tasca afegida: \"" + neta + "\"";
      println(missatge);
      textEscrit = "";
    }
  } else if (key == BACKSPACE) {
    if (textEscrit.length() > 0) {
      textEscrit = textEscrit.substring(0, textEscrit.length() - 1);
    }
  } else if (key != CODED && key >= 32) {
    textEscrit += key;
    missatge = "Escrivint nova tasca: " + textEscrit;
  }
}
