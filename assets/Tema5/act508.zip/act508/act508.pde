/*
 * Activitat 508. Gestor de puntuacions amb ArrayList<Integer>
 * Gestiona puntuacions de manera dinàmica, permetent afegir, mostrar,
 * calcular màxim, mínim i mitjana, buscar, eliminar i ordenar de menor a major,
 * controlant casos límit com llista buida, valors negatius o opcions invàlides.
 */

import java.util.ArrayList;
import java.util.Collections;

ArrayList<Integer> puntuacions;
String ultimMissatge = "Prem una tecla d'opció (1-8 o 0 per eixir).";

void setup() {
  size(680, 340);
  puntuacions = new ArrayList<Integer>();

  // Dades inicials d'exemple
  puntuacions.add(150);
  puntuacions.add(80);
  puntuacions.add(220);
  puntuacions.add(150);

  mostrarMenu();
  mostrarLlistaConsola();
}

void draw() {
  background(245);

  fill(25);
  textSize(19);
  text("Activitat 508 - Gestor de puntuacions (ArrayList<Integer>)", 25, 35);

  textSize(14);
  fill(60);
  text("Puntuacions registrades (" + puntuacions.size() + "): " + puntuacions, 25, 72, width - 50, 45);

  fill(25);
  textSize(13);
  text("[1] Afegir   [2] Mostrar   [3] Màxim   [4] Mínim", 25, 135);
  text("[5] Mitjana  [6] Buscar    [7] Eliminar [8] Ordenar   [0] Eixir", 25, 160);

  fill(15, 80, 150);
  textSize(14);
  text("Estat: " + ultimMissatge, 25, 210, width - 50, 60);

  fill(95);
  textSize(12);
  text("Les accions interactives s'executen per consola i es reflecteixen ací.", 25, 295);
}

void mostrarMenu() {
  println("\n=== MENÚ GESTOR DE PUNTUACIONS ===");
  println("1. Afegir puntuació");
  println("2. Mostrar puntuacions");
  println("3. Mostrar puntuació màxima");
  println("4. Mostrar puntuació mínima");
  println("5. Calcular mitjana");
  println("6. Buscar una puntuació");
  println("7. Eliminar una puntuació");
  println("8. Ordenar puntuacions de menor a major");
  println("0. Eixir");
}

void mostrarLlistaConsola() {
  if (puntuacions.isEmpty()) {
    println("No hi ha cap puntuació registrada.");
  } else {
    print("Puntuacions actuals: ");
    for (int i = 0; i < puntuacions.size(); i++) {
      print(puntuacions.get(i));
      if (i < puntuacions.size() - 1) {
        print(", ");
      }
    }
    println();
  }
}

void keyPressed() {
  // Amb tecles 1-8 i 0 simulem i executem directament cada opció del menú
  if (key == '1') {
    // Exemple d'afegir una puntuació vàlida (per canviar-la, canvia el valor o fes proves)
    int novaPunt = int(random(-20, 301)); // pot generar valors negatius per provar la validació
    if (novaPunt < 0) {
      ultimMissatge = "Error: no es permeten puntuacions negatives (" + novaPunt + ").";
      println(ultimMissatge);
    } else {
      puntuacions.add(novaPunt);
      ultimMissatge = "S'ha afegit la puntuació: " + novaPunt;
      println(ultimMissatge);
    }
    mostrarLlistaConsola();
  } else if (key == '2') {
    if (puntuacions.isEmpty()) {
      ultimMissatge = "La llista està buida; no hi ha puntuacions per mostrar.";
    } else {
      ultimMissatge = "Llistat mostrat per consola (" + puntuacions.size() + " elements).";
    }
    println(ultimMissatge);
    mostrarLlistaConsola();
  } else if (key == '3') {
    if (puntuacions.isEmpty()) {
      ultimMissatge = "No es pot calcular el màxim: la llista està buida.";
    } else {
      int max = puntuacions.get(0);
      for (int i = 1; i < puntuacions.size(); i++) {
        if (puntuacions.get(i) > max) {
          max = puntuacions.get(i);
        }
      }
      ultimMissatge = "Puntuació màxima: " + max;
    }
    println(ultimMissatge);
  } else if (key == '4') {
    if (puntuacions.isEmpty()) {
      ultimMissatge = "No es pot calcular el mínim: la llista està buida.";
    } else {
      int min = puntuacions.get(0);
      for (int i = 1; i < puntuacions.size(); i++) {
        if (puntuacions.get(i) < min) {
          min = puntuacions.get(i);
        }
      }
      ultimMissatge = "Puntuació mínima: " + min;
    }
    println(ultimMissatge);
  } else if (key == '5') {
    if (puntuacions.isEmpty()) {
      ultimMissatge = "No es pot calcular la mitjana: la llista està buida.";
    } else {
      int suma = 0;
      for (int i = 0; i < puntuacions.size(); i++) {
        suma += puntuacions.get(i);
      }
      float mitjana = (float) suma / puntuacions.size();
      ultimMissatge = "Mitjana de puntuacions: " + nf(mitjana, 1, 2);
    }
    println(ultimMissatge);
  } else if (key == '6') {
    if (puntuacions.isEmpty()) {
      ultimMissatge = "No es pot buscar: la llista està buida.";
    } else {
      int buscada = 150;
      int vegades = 0;
      for (int i = 0; i < puntuacions.size(); i++) {
        if (puntuacions.get(i) == buscada) {
          vegades++;
        }
      }
      if (vegades > 0) {
        ultimMissatge = "La puntuació " + buscada + " apareix " + vegades + " vegada/vegades.";
      } else {
        ultimMissatge = "La puntuació " + buscada + " no existeix a la llista.";
      }
    }
    println(ultimMissatge);
  } else if (key == '7') {
    if (puntuacions.isEmpty()) {
      ultimMissatge = "No es pot eliminar: la llista està buida.";
    } else {
      Integer aEliminar = Integer.valueOf(150);
      boolean eliminat = puntuacions.remove(aEliminar);
      if (eliminat) {
        ultimMissatge = "S'ha eliminat una aparició de la puntuació " + aEliminar + ".";
      } else {
        ultimMissatge = "No s'ha pogut eliminar: la puntuació " + aEliminar + " no existeix.";
      }
    }
    println(ultimMissatge);
    mostrarLlistaConsola();
  } else if (key == '8') {
    if (puntuacions.isEmpty()) {
      ultimMissatge = "No es pot ordenar: la llista està buida.";
    } else {
      Collections.sort(puntuacions);
      ultimMissatge = "Puntuacions ordenades de menor a major.";
    }
    println(ultimMissatge);
    mostrarLlistaConsola();
  } else if (key == '0') {
    ultimMissatge = "Eixint del gestor de puntuacions...";
    println(ultimMissatge);
    exit();
  } else if (key != CODED) {
    ultimMissatge = "Opció no vàlida ('" + key + "'). Tria entre 1-8 o 0.";
    println(ultimMissatge);
  }
}
