/*
 * Activitat 509. Puntuacions amb ArrayList<Integer> i HashSet<Integer>
 * Genera 30 puntuacions aleatòries entre 0 i 10, les guarda en un ArrayList
 * (conservant duplicats) i en un HashSet (valors únics), mostra els recomptes
 * i les freqüències de cada puntuació, i calcula la més repetida (amb empats).
 */

import java.util.ArrayList;
import java.util.HashSet;

ArrayList<Integer> llistaPuntuacions;
HashSet<Integer> conjuntPuntuacions;
int[] frequencies = new int[11]; // índexs 0..10
int maxFrequencia = 0;
ArrayList<Integer> mesRepetides = new ArrayList<Integer>();

void setup() {
  size(720, 420);
  background(245);

  llistaPuntuacions = new ArrayList<Integer>();
  conjuntPuntuacions = new HashSet<Integer>();

  // 1. Generació de 30 puntuacions aleatòries entre 0 i 10
  for (int i = 0; i < 30; i++) {
    int punt = int(random(11)); // 0..10 inclosos
    llistaPuntuacions.add(punt);
    conjuntPuntuacions.add(punt);
  }

  // 2. Comptatge de quantes vegades apareix cada puntuació (0..10)
  for (int i = 0; i < llistaPuntuacions.size(); i++) {
    int valor = llistaPuntuacions.get(i);
    frequencies[valor]++;
  }

  // 3. Ampliació: puntuació o puntuacions més repetides (gestionant empats)
  for (int p = 0; p < frequencies.length; p++) {
    if (frequencies[p] > maxFrequencia) {
      maxFrequencia = frequencies[p];
      mesRepetides.clear();
      mesRepetides.add(p);
    } else if (frequencies[p] == maxFrequencia && maxFrequencia > 0) {
      mesRepetides.add(p);
    }
  }

  // 4. Mostra per consola
  println("=== ACTIVITAT 509: PUNTUACIONS ===");
  println("Totes les puntuacions (" + llistaPuntuacions.size() + "):");
  for (int i = 0; i < llistaPuntuacions.size(); i++) {
    print(llistaPuntuacions.get(i));
    if (i < llistaPuntuacions.size() - 1) {
      print(", ");
    }
  }
  println();

  println("Puntuacions diferents (" + conjuntPuntuacions.size() + "):");
  println(conjuntPuntuacions);

  println("Nombre de puntuacions generades: " + llistaPuntuacions.size());
  println("Nombre de puntuacions diferents: " + conjuntPuntuacions.size());

  println("Freqüència de cada puntuació:");
  for (int p = 0; p < frequencies.length; p++) {
    println("  Puntuació " + p + ": " + frequencies[p] + " vegada/vegades");
  }

  println("Puntuació/ons més repetida/es (" + maxFrequencia + " vegades): " + mesRepetides);

  // 5. Representació visual al canvas
  fill(25);
  textSize(19);
  text("Activitat 509 - Puntuacions (ArrayList vs HashSet)", 25, 35);

  textSize(13);
  String textLlista = "Totes (" + llistaPuntuacions.size() + "): ";
  for (int i = 0; i < llistaPuntuacions.size(); i++) {
    textLlista += llistaPuntuacions.get(i) + (i < llistaPuntuacions.size() - 1 ? ", " : "");
  }
  text(textLlista, 25, 65, width - 50, 45);

  text("Diferents (" + conjuntPuntuacions.size() + "): " + conjuntPuntuacions, 25, 118);
  text("Total generades: " + llistaPuntuacions.size() + "   |   Total diferents: " + conjuntPuntuacions.size(), 25, 145);

  text("Freqüències (0-10):", 25, 180);
  for (int p = 0; p < frequencies.length; p++) {
    int col = p < 6 ? 0 : 1;
    int fila = p < 6 ? p : p - 6;
    int x = 35 + col * 240;
    int y = 205 + fila * 24;
    text("• Punt " + p + " -> " + frequencies[p] + " vegades", x, y);
  }

  fill(20, 110, 60);
  textSize(14);
  text("Més repetida (" + maxFrequencia + " vegades): " + mesRepetides, 25, 375);
}
