/*
 * Activitat 510. Control d'assistència amb HashSet<String> i ArrayList<String>
 * Gestiona els alumnes presents evitant duplicats amb un HashSet i conserva
 * l'ordre d'arribada amb un ArrayList. Inclou control de conjunt buit i
 * reflexió final sobre l'ús de les dues estructures.
 *
 * REFLEXIÓ SOBRE L'ÚS DE DUES ESTRUCTURES (HashSet + ArrayList):
 * - HashSet<String> garanteix que cada alumne aparega una sola vegada i permet
 *   comprovar ràpidament si ja està registrat (contains()) o eliminar-lo (remove()),
 *   però no conserva l'ordre d'inserció.
 * - ArrayList<String> conserva l'ordre exacte en què els alumnes han anat arribant,
 *   per la qual cosa complementar-lo amb el HashSet permet mostrar tant els presents
 *   actuals com la seqüència d'arribada.
 */

import java.util.HashSet;
import java.util.ArrayList;
import java.util.Iterator;

HashSet<String> assistents;
ArrayList<String> ordreEntrada;

String ultimMissatge = "Prem una tecla d'opció (1-6 o 0 per eixir).";
String textEntrada = "";
int modeAccio = 0; // 0: menú, 1: registrar, 2: comprovar, 5: eliminar

void setup() {
  size(740, 420);
  assistents = new HashSet<String>();
  ordreEntrada = new ArrayList<String>();

  // Dades inicials d'exemple
  String[] inicials = {"Anna", "Pau", "Maria"};
  for (int i = 0; i < inicials.length; i++) {
    assistents.add(inicials[i]);
    ordreEntrada.add(inicials[i]);
  }

  mostrarMenu();
}

void draw() {
  background(245);

  fill(25);
  textSize(19);
  text("Activitat 510 - Control d'assistència (HashSet + ArrayList)", 25, 35);

  fill(60);
  textSize(14);
  text("Assistents presents (" + assistents.size() + "): " + assistents, 25, 70, width - 50, 40);
  text("Ordre d'arribada: " + ordreEntrada, 25, 112, width - 50, 40);

  fill(25);
  textSize(13);
  text("[1] Registrar alumne     [2] Comprovar assistència   [3] Mostrar assistents", 25, 175);
  text("[4] Nombre d'assistents  [5] Eliminar alumne         [6] Esborrar assistència   [0] Eixir", 25, 200);

  if (modeAccio != 0) {
    fill(140, 60, 10);
    textSize(14);
    text("Escriu el nom i prem ENTER: " + textEntrada + "_", 25, 245);
  }

  fill(15, 80, 150);
  textSize(14);
  text("Estat: " + ultimMissatge, 25, 290, width - 50, 65);

  fill(95);
  textSize(12);
  text("També pots fer proves ràpides amb [R] (registra 'Marc') o [D] (elimina 'Pau').", 25, 380);
}

void mostrarMenu() {
  println("\n=== MENÚ CONTROL D'ASSISTÈNCIA ===");
  println("1. Registrar alumne");
  println("2. Comprovar assistència");
  println("3. Mostrar assistents");
  println("4. Mostrar nombre d'assistents");
  println("5. Eliminar alumne");
  println("6. Esborrar l'assistència");
  println("0. Eixir");
}

void keyPressed() {
  // Si estem introduint un nom per teclat
  if (modeAccio != 0) {
    if (key == ENTER || key == RETURN) {
      String nom = textEntrada.trim();
      textEntrada = "";
      int accioActual = modeAccio;
      modeAccio = 0;

      if (nom.length() == 0) {
        ultimMissatge = "El nom no pot estar buit.";
        println(ultimMissatge);
        return;
      }

      if (accioActual == 1) {
        // 1. Registrar alumne
        boolean afegit = assistents.add(nom);
        if (afegit) {
          ordreEntrada.add(nom);
          ultimMissatge = "Alumne registrat correctament (" + nom + ").";
        } else {
          ultimMissatge = "L'alumne ja estava registrat (" + nom + ").";
        }
        println(ultimMissatge);
      } else if (accioActual == 2) {
        // 2. Comprovar assistència
        if (assistents.isEmpty()) {
          ultimMissatge = "No hi ha cap alumne registrat actualment.";
        } else if (assistents.contains(nom)) {
          ultimMissatge = nom + " SÍ consta com a assistent.";
        } else {
          ultimMissatge = nom + " NO està en la llista d'assistents.";
        }
        println(ultimMissatge);
      } else if (accioActual == 5) {
        // 5. Eliminar alumne
        if (assistents.isEmpty()) {
          ultimMissatge = "No es pot eliminar ningú: el conjunt d'assistents està buit.";
        } else if (assistents.remove(nom)) {
          ordreEntrada.remove(nom);
          ultimMissatge = "S'ha eliminat " + nom + " dels assistents.";
        } else {
          ultimMissatge = "L'alumne '" + nom + "' no figura entre els assistents.";
        }
        println(ultimMissatge);
      }
      return;
    } else if (key == BACKSPACE) {
      if (textEntrada.length() > 0) {
        textEntrada = textEntrada.substring(0, textEntrada.length() - 1);
      }
      return;
    } else if (key == ESC) {
      modeAccio = 0;
      textEntrada = "";
      ultimMissatge = "Operació cancel·lada.";
      key = 0;
      return;
    } else if (key != CODED && key >= 32) {
      textEntrada += key;
      return;
    }
  }

  // Selecció d'opcions del menú
  if (key == '1') {
    modeAccio = 1;
    textEntrada = "";
    ultimMissatge = "Registrar alumne -> escriu un nom i prem ENTER.";
  } else if (key == '2') {
    modeAccio = 2;
    textEntrada = "";
    ultimMissatge = "Comprovar assistència -> escriu un nom i prem ENTER.";
  } else if (key == '3') {
    // 3. Mostrar assistents (presents i ordre d'arribada)
    if (assistents.isEmpty()) {
      ultimMissatge = "El conjunt d'assistents està buit.";
      println(ultimMissatge);
    } else {
      println("--- ASSISTENTS PRESENTS ---");
      Iterator<String> it = assistents.iterator();
      while (it.hasNext()) {
        println("  • " + it.next());
      }
      println("--- ORDRE D'ARRIBADA ---");
      for (int i = 0; i < ordreEntrada.size(); i++) {
        println("  " + (i + 1) + ". " + ordreEntrada.get(i));
      }
      ultimMissatge = "Assistents i ordre d'arribada mostrats per consola.";
    }
  } else if (key == '4') {
    // 4. Mostrar nombre d'assistents
    ultimMissatge = "Nombre d'assistents actuals: " + assistents.size();
    println(ultimMissatge);
  } else if (key == '5') {
    if (assistents.isEmpty()) {
      ultimMissatge = "No hi ha cap alumne per eliminar: el conjunt està buit.";
      println(ultimMissatge);
    } else {
      modeAccio = 5;
      textEntrada = "";
      ultimMissatge = "Eliminar alumne -> escriu un nom i prem ENTER.";
    }
  } else if (key == '6') {
    // 6. Esborrar l'assistència
    if (assistents.isEmpty()) {
      ultimMissatge = "L'assistència ja estava buida.";
    } else {
      assistents.clear();
      ordreEntrada.clear();
      ultimMissatge = "S'ha esborrat tota l'assistència.";
    }
    println(ultimMissatge);
  } else if (key == 'r' || key == 'R') {
    if (assistents.add("Marc")) {
      ordreEntrada.add("Marc");
      ultimMissatge = "Alumne registrat correctament (Marc).";
    } else {
      ultimMissatge = "L'alumne ja estava registrat (Marc).";
    }
    println(ultimMissatge);
  } else if (key == 'd' || key == 'D') {
    if (assistents.remove("Pau")) {
      ordreEntrada.remove("Pau");
      ultimMissatge = "S'ha eliminat Pau dels assistents.";
    } else {
      ultimMissatge = "Pau no estava entre els assistents.";
    }
    println(ultimMissatge);
  } else if (key == '0') {
    ultimMissatge = "Eixint del control d'assistència...";
    println(ultimMissatge);
    exit();
  } else if (key != CODED) {
    ultimMissatge = "Opció no vàlida ('" + key + "'). Tria entre 1-6 o 0.";
    println(ultimMissatge);
  }
}
