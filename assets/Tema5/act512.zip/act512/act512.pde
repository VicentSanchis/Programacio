/*
 * Activitat 512. Inventari d'una botiga amb HashMap
 * Gestiona un inventari de productes (codi -> nom i codi -> quantitat) amb
 * opcions per afegir, consultar, reposar, vendre, eliminar, llistar, detectar
 * productes sense existències, mostrar el total de codis i esborrar.
 */

import java.util.HashMap;
import java.util.Map;

HashMap<String, String> productes;
HashMap<String, Integer> existencies;

String ultimMissatge = "Prem una tecla d'opció (1-8, [C] buidar o [0] eixir).";
int modeAccio = 0; // 0: menú | 1: afegir | 2: consultar | 3: reposar | 4: vendre | 5: eliminar
int pasEntrada = 0; // 1: demana codi | 2: demana nom | 3: demana quantitat
String textEntrada = "";
String codiTemporal = "";
String nomTemporal = "";

void setup() {
  size(760, 440);
  productes = new HashMap<String, String>();
  existencies = new HashMap<String, Integer>();

  // Dades inicials d'exemple
  registrarInicial("A001", "Teclat mecànic", 15);
  registrarInicial("A002", "Ratolí sense fil", 7);
  registrarInicial("A003", "Monitor 24\"", 0);

  mostrarMenu();
  mostrarInventariConsola();
}

void registrarInicial(String codi, String nom, int quantitat) {
  productes.put(codi, nom);
  existencies.put(codi, quantitat);
}

void draw() {
  background(245);

  fill(25);
  textSize(19);
  text("Activitat 512 - Inventari d'una botiga (HashMap)", 25, 35);

  fill(60);
  textSize(14);
  text("Nombre de productes diferents (size()): " + existencies.size(), 25, 68);

  // Mostra el llistat actual de l'inventari
  fill(25);
  textSize(13);
  int yLlista = 100;
  if (existencies.isEmpty()) {
    fill(160, 40, 40);
    text("L'inventari està buit.", 35, yLlista);
  } else {
    for (Map.Entry<String, Integer> entrada : existencies.entrySet()) {
      String codi = entrada.getKey();
      int quantitat = entrada.getValue();
      String nom = productes.getOrDefault(codi, "Sense nom");
      text("• " + codi + " (" + nom + ") -> " + quantitat + " unitats", 35, yLlista);
      yLlista += 22;
    }
  }

  // Opcions del menú
  int yMenu = 235;
  fill(25);
  textSize(13);
  text("[1] Afegir producte     [2] Consultar existències   [3] Reposar producte    [4] Vendre producte", 25, yMenu);
  text("[5] Eliminar producte   [6] Mostrar inventari       [7] Sense existències   [8] Nombre productes", 25, yMenu + 22);
  text("[C] Buidar inventari (clear())   |   [0] Eixir", 25, yMenu + 44);

  if (modeAccio != 0) {
    fill(140, 60, 10);
    textSize(14);
    String instruccio = "";
    if (pasEntrada == 1) instruccio = "Escriu el CODI del producte i prem ENTER: ";
    else if (pasEntrada == 2) instruccio = "Escriu el NOM del producte i prem ENTER: ";
    else if (pasEntrada == 3) instruccio = "Escriu la QUANTITAT i prem ENTER: ";
    text(instruccio + textEntrada + "_", 25, 325);
  }

  fill(15, 80, 150);
  textSize(14);
  text("Estat: " + ultimMissatge, 25, 365, width - 50, 60);
}

void mostrarMenu() {
  println("\n=== MENÚ INVENTARI DE LA BOTIGA ===");
  println("1. Afegir producte");
  println("2. Consultar existències");
  println("3. Reposar producte");
  println("4. Vendre producte");
  println("5. Eliminar producte");
  println("6. Mostrar inventari");
  println("7. Mostrar productes sense existències");
  println("8. Mostrar nombre de productes");
  println("0. Eixir");
}

void mostrarInventariConsola() {
  if (existencies.isEmpty()) {
    println("L'inventari no té cap producte.");
  } else {
    println("--- INVENTARI ACTUAL ---");
    for (Map.Entry<String, Integer> entrada : existencies.entrySet()) {
      String codi = entrada.getKey();
      int quant = entrada.getValue();
      String nom = productes.getOrDefault(codi, "Producte");
      println(codi + " (" + nom + ") -> " + quant + " unitats");
    }
  }
}

void keyPressed() {
  if (modeAccio != 0) {
    if (key == ENTER || key == RETURN) {
      String valor = textEntrada.trim();
      textEntrada = "";

      if (valor.length() == 0) {
        ultimMissatge = "El camp no pot estar buit.";
        println(ultimMissatge);
        return;
      }

      if (modeAccio == 1) {
        // 1. Afegir producte (codi -> nom -> quantitat inicial)
        if (pasEntrada == 1) {
          codiTemporal = valor.toUpperCase();
          if (existencies.containsKey(codiTemporal)) {
            ultimMissatge = "Error: ja existeix un producte amb el codi " + codiTemporal + ".";
            println(ultimMissatge);
            modeAccio = 0;
            pasEntrada = 0;
          } else {
            pasEntrada = 2;
            ultimMissatge = "Codi " + codiTemporal + " disponible. Escriu el nom del producte.";
          }
        } else if (pasEntrada == 2) {
          nomTemporal = valor;
          pasEntrada = 3;
          ultimMissatge = "Escriu la quantitat inicial per a '" + nomTemporal + "'.";
        } else if (pasEntrada == 3) {
          int quant = int(valor);
          if (quant < 0) {
            ultimMissatge = "Error: la quantitat inicial no pot ser negativa.";
          } else {
            productes.put(codiTemporal, nomTemporal);
            existencies.put(codiTemporal, quant);
            ultimMissatge = "Producte afegit: " + codiTemporal + " (" + nomTemporal + ") -> " + quant + " unitats.";
          }
          println(ultimMissatge);
          modeAccio = 0;
          pasEntrada = 0;
        }
      } else if (modeAccio == 2) {
        // 2. Consultar existències
        String codi = valor.toUpperCase();
        if (existencies.containsKey(codi)) {
          int quant = existencies.get(codi);
          String nom = productes.getOrDefault(codi, "Sense nom");
          ultimMissatge = "Existències de " + codi + " (" + nom + "): " + quant + " unitats.";
        } else {
          ultimMissatge = "No s'ha trobat cap producte amb el codi " + codi + ".";
        }
        println(ultimMissatge);
        modeAccio = 0;
        pasEntrada = 0;
      } else if (modeAccio == 3) {
        // 3. Reposar producte
        if (pasEntrada == 1) {
          codiTemporal = valor.toUpperCase();
          if (!existencies.containsKey(codiTemporal)) {
            ultimMissatge = "Error: el codi " + codiTemporal + " no existeix.";
            println(ultimMissatge);
            modeAccio = 0;
            pasEntrada = 0;
          } else {
            pasEntrada = 3;
            ultimMissatge = "Quantes unitats vols reposar del producte " + codiTemporal + "?";
          }
        } else if (pasEntrada == 3) {
          int afegir = int(valor);
          if (afegir <= 0) {
            ultimMissatge = "Error: la quantitat a reposar ha de ser major que 0.";
          } else {
            int actual = existencies.getOrDefault(codiTemporal, 0);
            existencies.put(codiTemporal, actual + afegir);
            ultimMissatge = "Reposats +" + afegir + " unitats de " + codiTemporal + ". Total: " + (actual + afegir);
          }
          println(ultimMissatge);
          modeAccio = 0;
          pasEntrada = 0;
        }
      } else if (modeAccio == 4) {
        // 4. Vendre producte
        if (pasEntrada == 1) {
          codiTemporal = valor.toUpperCase();
          if (!existencies.containsKey(codiTemporal)) {
            ultimMissatge = "Error: el codi " + codiTemporal + " no existeix.";
            println(ultimMissatge);
            modeAccio = 0;
            pasEntrada = 0;
          } else {
            pasEntrada = 3;
            ultimMissatge = "Quantes unitats vols vendre del producte " + codiTemporal + "?";
          }
        } else if (pasEntrada == 3) {
          int vendes = int(valor);
          int actual = existencies.getOrDefault(codiTemporal, 0);
          if (vendes <= 0) {
            ultimMissatge = "Error: la quantitat a vendre ha de ser major que 0.";
          } else if (vendes > actual) {
            ultimMissatge = "No hi ha prou existències de " + codiTemporal + " (disponibles: " + actual + ").";
          } else {
            existencies.put(codiTemporal, actual - vendes);
            ultimMissatge = "Venda realitzada (" + vendes + " unitats de " + codiTemporal + "). Queden: " + (actual - vendes);
          }
          println(ultimMissatge);
          modeAccio = 0;
          pasEntrada = 0;
        }
      } else if (modeAccio == 5) {
        // 5. Eliminar producte
        String codi = valor.toUpperCase();
        if (existencies.containsKey(codi)) {
          existencies.remove(codi);
          productes.remove(codi);
          ultimMissatge = "Producte " + codi + " eliminat de l'inventari.";
        } else {
          ultimMissatge = "No s'ha pogut eliminar: el codi " + codi + " no existeix.";
        }
        println(ultimMissatge);
        modeAccio = 0;
        pasEntrada = 0;
      }
      return;
    } else if (key == BACKSPACE) {
      if (textEntrada.length() > 0) {
        textEntrada = textEntrada.substring(0, textEntrada.length() - 1);
      }
      return;
    } else if (key == ESC) {
      modeAccio = 0;
      pasEntrada = 0;
      textEntrada = "";
      ultimMissatge = "Operació cancel·lada.";
      key = 0;
      return;
    } else if (key != CODED && key >= 32) {
      textEntrada += key;
      return;
    }
  }

  // Selecció directa d'opcions del menú
  if (key == '1') {
    modeAccio = 1;
    pasEntrada = 1;
    textEntrada = "";
    ultimMissatge = "Afegir producte -> escriu el codi i prem ENTER.";
  } else if (key == '2') {
    modeAccio = 2;
    pasEntrada = 1;
    textEntrada = "";
    ultimMissatge = "Consultar existències -> escriu el codi i prem ENTER.";
  } else if (key == '3') {
    modeAccio = 3;
    pasEntrada = 1;
    textEntrada = "";
    ultimMissatge = "Reposar producte -> escriu el codi i prem ENTER.";
  } else if (key == '4') {
    modeAccio = 4;
    pasEntrada = 1;
    textEntrada = "";
    ultimMissatge = "Vendre producte -> escriu el codi i prem ENTER.";
  } else if (key == '5') {
    modeAccio = 5;
    pasEntrada = 1;
    textEntrada = "";
    ultimMissatge = "Eliminar producte -> escriu el codi i prem ENTER.";
  } else if (key == '6') {
    // 6. Mostrar inventari
    mostrarInventariConsola();
    ultimMissatge = "Inventari mostrat per consola.";
  } else if (key == '7') {
    // 7. Productes sense existències (quantitat == 0)
    String senseEstoc = "";
    for (Map.Entry<String, Integer> entrada : existencies.entrySet()) {
      if (entrada.getValue() == 0) {
        String c = entrada.getKey();
        senseEstoc += c + " (" + productes.getOrDefault(c, "Sense nom") + ") ";
      }
    }
    if (senseEstoc.length() == 0) {
      ultimMissatge = "Tots els productes tenen existències disponibles.";
    } else {
      ultimMissatge = "Sense existències: " + senseEstoc;
    }
    println(ultimMissatge);
  } else if (key == '8') {
    // 8. Nombre de productes
    ultimMissatge = "Nombre de codis diferents a l'inventari: " + existencies.size();
    println(ultimMissatge);
  } else if (key == 'c' || key == 'C') {
    existencies.clear();
    productes.clear();
    ultimMissatge = "S'ha buidat completament l'inventari (clear()).";
    println(ultimMissatge);
  } else if (key == '0') {
    ultimMissatge = "Eixint del gestor d'inventari...";
    println(ultimMissatge);
    exit();
  } else if (key != CODED) {
    ultimMissatge = "Opció no vàlida ('" + key + "').";
    println(ultimMissatge);
  }
}
