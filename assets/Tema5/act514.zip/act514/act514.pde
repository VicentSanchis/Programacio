/*
 * Activitat 514. Gestor de cua d'atenció al públic amb LinkedList<String>
 * Gestiona una cua d'espera permetent afegir al final, atendre el primer,
 * consultar el següent, mostrar la cua, veure el nombre de persones, afegir
 * amb prioritat al principi i atendre l'última persona, controlant la cua buida.
 */

import java.util.LinkedList;
import java.util.Queue;
import java.util.Deque;

LinkedList<String> cua;
// Variants d'ampliació (es poden provar canviant la referència):
// Queue<String> cuaQueue = new LinkedList<String>();
// Deque<String> cuaDeque = new LinkedList<String>();

String ultimMissatge = "Prem una tecla d'opció (1-7 o 0 per eixir).";
int modeAccio = 0; // 0: menú | 1: afegir persona | 6: afegir amb prioritat
String textEntrada = "";
int comptadorPersones = 1;

void setup() {
  size(760, 400);
  cua = new LinkedList<String>();

  // Persones inicials a la cua
  cua.addLast("Clara");
  cua.addLast("Jordi");
  cua.addLast("Laia");

  mostrarMenu();
  mostrarCuaConsola();
}

void draw() {
  background(245);

  fill(25);
  textSize(19);
  text("Activitat 514 - Gestor de cua d'atenció al públic (LinkedList)", 25, 35);

  fill(60);
  textSize(14);
  text("Persones esperant (size()): " + cua.size(), 25, 68);

  // Mostra la cua actual
  fill(25);
  textSize(13);
  if (cua.isEmpty()) {
    fill(160, 40, 40);
    text("La cua està buida: no hi ha ningú esperant.", 35, 102);
  } else {
    String textCua = "Cua (principi -> final): ";
    for (int i = 0; i < cua.size(); i++) {
      textCua += "[" + (i + 1) + "] " + cua.get(i);
      if (i < cua.size() - 1) {
        textCua += "  ->  ";
      }
    }
    text(textCua, 25, 102, width - 50, 50);
  }

  // Menú d'opcions
  int yMenu = 175;
  fill(25);
  textSize(13);
  text("[1] Afegir persona (final)   [2] Atendre persona (1r)   [3] Consultar següent   [4] Mostrar cua", 25, yMenu);
  text("[5] Nombre de persones       [6] Prioritat (principi)    [7] Atendre últim      [0] Eixir", 25, yMenu + 24);

  if (modeAccio != 0) {
    fill(140, 60, 10);
    textSize(14);
    String tipus = (modeAccio == 6) ? "amb prioritat (principi)" : "al final";
    text("Escriu el nom de la persona " + tipus + " i prem ENTER: " + textEntrada + "_", 25, 250);
  }

  fill(15, 80, 150);
  textSize(14);
  text("Estat: " + ultimMissatge, 25, 295, width - 50, 60);

  fill(95);
  textSize(12);
  text("Dreceres ràpides: [A] afegeix persona automàtica al final | [P] afegeix persona prioritària al principi.", 25, 370);
}

void mostrarMenu() {
  println("\n=== MENÚ GESTOR DE CUA ===");
  println("1. Afegir persona (final)");
  println("2. Atendre persona (primera)");
  println("3. Consultar qui serà la següent");
  println("4. Mostrar cua");
  println("5. Mostrar nombre de persones");
  println("6. Afegir persona amb prioritat (principi)");
  println("7. Atendre l'última persona");
  println("0. Eixir");
}

void mostrarCuaConsola() {
  if (cua.isEmpty()) {
    println("La cua està buida.");
  } else {
    print("Estat de la cua (" + cua.size() + "): ");
    for (int i = 0; i < cua.size(); i++) {
      print(cua.get(i));
      if (i < cua.size() - 1) {
        print(" -> ");
      }
    }
    println();
  }
}

void keyPressed() {
  if (modeAccio != 0) {
    if (key == ENTER || key == RETURN) {
      String nom = textEntrada.trim();
      textEntrada = "";
      int accio = modeAccio;
      modeAccio = 0;

      if (nom.length() == 0) {
        ultimMissatge = "El nom no pot estar buit.";
        println(ultimMissatge);
        return;
      }

      if (accio == 1) {
        cua.addLast(nom);
        ultimMissatge = "S'ha afegit " + nom + " al final de la cua.";
      } else if (accio == 6) {
        cua.addFirst(nom);
        ultimMissatge = "S'ha afegit " + nom + " amb prioritat al principi de la cua.";
      }
      println(ultimMissatge);
      mostrarCuaConsola();
      return;
    } else if (key == BACKSPACE) {
      if (textEntrada.length() > 0) {
        textEntrada = textEntrada.substring(0, textEntrada.length() - 1);
      }
      return;
    } else if (key == ESC) {
      modeAccio = 0;
      textEntrada = "";
      ultimMissatge = "Operació cancel·lada.";
      key = 0;
      return;
    } else if (key != CODED && key >= 32) {
      textEntrada += key;
      return;
    }
  }

  if (key == '1') {
    modeAccio = 1;
    textEntrada = "";
    ultimMissatge = "Afegir persona -> escriu el nom i prem ENTER.";
  } else if (key == 'a' || key == 'A') {
    String nom = "Usuari" + comptadorPersones++;
    cua.addLast(nom);
    ultimMissatge = "S'ha afegit " + nom + " al final de la cua.";
    println(ultimMissatge);
    mostrarCuaConsola();
  } else if (key == '2') {
    if (cua.isEmpty()) {
      ultimMissatge = "No es pot atendre ningú: la cua està buida.";
    } else {
      String atesa = cua.removeFirst();
      ultimMissatge = "S'ha atés la primera persona: " + atesa + ".";
    }
    println(ultimMissatge);
    mostrarCuaConsola();
  } else if (key == '3') {
    if (cua.isEmpty()) {
      ultimMissatge = "No hi ha ningú per consultar: la cua està buida.";
    } else {
      String seguent = cua.getFirst();
      ultimMissatge = "La següent persona a ser atesa és: " + seguent + ".";
    }
    println(ultimMissatge);
  } else if (key == '4') {
    mostrarCuaConsola();
    ultimMissatge = cua.isEmpty() ? "La cua està buida." : "Cua mostrada per consola.";
  } else if (key == '5') {
    ultimMissatge = "Nombre de persones esperant: " + cua.size() + ".";
    println(ultimMissatge);
  } else if (key == '6') {
    modeAccio = 6;
    textEntrada = "";
    ultimMissatge = "Afegir persona amb prioritat -> escriu el nom i prem ENTER.";
  } else if (key == 'p' || key == 'P') {
    String nom = "Prioritari" + comptadorPersones++;
    cua.addFirst(nom);
    ultimMissatge = "S'ha afegit " + nom + " al principi amb prioritat.";
    println(ultimMissatge);
    mostrarCuaConsola();
  } else if (key == '7') {
    if (cua.isEmpty()) {
      ultimMissatge = "No es pot atendre l'última persona: la cua està buida.";
    } else {
      String ultima = cua.removeLast();
      ultimMissatge = "S'ha atés l'última persona de la cua: " + ultima + ".";
    }
    println(ultimMissatge);
    mostrarCuaConsola();
  } else if (key == '0') {
    ultimMissatge = "Eixint del gestor de cua...";
    println(ultimMissatge);
    exit();
  } else if (key != CODED) {
    ultimMissatge = "Opció no vàlida ('" + key + "').";
    println(ultimMissatge);
  }
}
