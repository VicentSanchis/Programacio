/*
 * Activitat 515. Les col·leccions davant d'un problema (Participants d'un torneig)
 * Combina HashMap<String, Integer>, ArrayList<String>, HashSet<Integer> i
 * TreeSet<Integer> per registrar participants, evitar duplicats, consultar i
 * actualitzar puntuacions, mostrar tots els participants i llistar les
 * puntuacions diferents i ordenades.
 */

import java.util.HashMap;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Map;

HashMap<String, Integer> puntuacionsPerJugador;
ArrayList<String> ordreParticipants;
HashSet<Integer> puntuacionsDiferents;
TreeSet<Integer> puntuacionsOrdenades;

String ultimMissatge = "Prem una tecla d'opció (1-7 o 0 per eixir).";
int modeAccio = 0; // 0: menú | 1: registrar | 3: consultar | 7: actualitzar puntuació
int pasEntrada = 0; // 1: nom participant | 2: puntuació
String textEntrada = "";
String nomTemporal = "";

void setup() {
  size(780, 440);
  puntuacionsPerJugador = new HashMap<String, Integer>();
  ordreParticipants = new ArrayList<String>();
  puntuacionsDiferents = new HashSet<Integer>();
  puntuacionsOrdenades = new TreeSet<Integer>();

  // Dades inicials d'exemple
  afegirParticipantInicial("Aina", 120);
  afegirParticipantInicial("Biel", 85);
  afegirParticipantInicial("Carla", 120);
  afegirParticipantInicial("David", 95);
  sincronitzarPuntuacions();

  mostrarMenu();
  mostrarTotsParticipantsConsola();
}

void afegirParticipantInicial(String nom, int punts) {
  if (!puntuacionsPerJugador.containsKey(nom)) {
    puntuacionsPerJugador.put(nom, punts);
    ordreParticipants.add(nom);
  }
}

void sincronitzarPuntuacions() {
  puntuacionsDiferents.clear();
  puntuacionsOrdenades.clear();
  for (Integer punt : puntuacionsPerJugador.values()) {
    puntuacionsDiferents.add(punt);
    puntuacionsOrdenades.add(punt);
  }
}

void draw() {
  background(245);

  fill(25);
  textSize(19);
  text("Activitat 515 - Gestió d'un torneig amb múltiples col·leccions", 25, 35);

  fill(60);
  textSize(13);
  text("Participants (" + ordreParticipants.size() + "): " + ordreParticipants, 25, 68, width - 50, 32);
  text("Puntuacions diferents (HashSet): " + puntuacionsDiferents, 25, 102);
  text("Puntuacions ordenades (TreeSet): " + puntuacionsOrdenades, 25, 126);

  // Detall de cada participant i la seua puntuació
  fill(25);
  textSize(13);
  int yLlista = 156;
  if (ordreParticipants.isEmpty()) {
    fill(160, 40, 40);
    text("No hi ha cap participant registrat.", 35, yLlista);
  } else {
    for (int i = 0; i < ordreParticipants.size(); i++) {
      String nom = ordreParticipants.get(i);
      int punts = puntuacionsPerJugador.get(nom);
      text("• " + (i + 1) + ". " + nom + " -> " + punts + " punts", 35, yLlista);
      yLlista += 20;
    }
  }

  // Menú d'opcions
  int yMenu = 250;
  fill(25);
  textSize(13);
  text("[1] Registrar participant   [3] Consultar puntuació   [4] Mostrar participants   [5] Punts diferents", 25, yMenu);
  text("[6] Punts ordenats          [7] Actualitzar punts    [0] Eixir", 25, yMenu + 22);

  if (modeAccio != 0) {
    fill(140, 60, 10);
    textSize(14);
    String instruccio = "";
    if (pasEntrada == 1) {
      instruccio = "Escriu el NOM del participant i prem ENTER: ";
    } else if (pasEntrada == 2) {
      instruccio = "Escriu la nova PUNTUACIÓ per a '" + nomTemporal + "' i prem ENTER: ";
    }
    text(instruccio + textEntrada + "_", 25, 312);
  }

  fill(15, 80, 150);
  textSize(14);
  text("Estat: " + ultimMissatge, 25, 355, width - 50, 65);
}

void mostrarMenu() {
  println("\n=== MENÚ DEL TORNEIG ===");
  println("1. Registrar participant");
  println("2. Evitar que un mateix participant es registre dues vegades (actiu en registrar)");
  println("3. Consultar la puntuació d'un participant");
  println("4. Mostrar tots els participants");
  println("5. Mostrar les puntuacions diferents");
  println("6. Mostrar les puntuacions ordenades");
  println("7. Actualitzar la puntuació d'un participant");
  println("0. Eixir");
}

void mostrarTotsParticipantsConsola() {
  if (ordreParticipants.isEmpty()) {
    println("No hi ha participants registrats.");
  } else {
    println("--- TOTS ELS PARTICIPANTS ---");
    for (int i = 0; i < ordreParticipants.size(); i++) {
      String nom = ordreParticipants.get(i);
      println("  " + (i + 1) + ". " + nom + " -> " + puntuacionsPerJugador.get(nom) + " punts");
    }
  }
}

void keyPressed() {
  if (modeAccio != 0) {
    if (key == ENTER || key == RETURN) {
      String valor = textEntrada.trim();
      textEntrada = "";

      if (valor.length() == 0) {
        ultimMissatge = "El camp no pot estar buit.";
        println(ultimMissatge);
        return;
      }

      if (modeAccio == 1) {
        // 1 i 2. Registrar participant evitant duplicats
        if (pasEntrada == 1) {
          if (puntuacionsPerJugador.containsKey(valor)) {
            ultimMissatge = "Registre denegat: el participant '" + valor + "' ja està registrat.";
            println(ultimMissatge);
            modeAccio = 0;
            pasEntrada = 0;
          } else {
            nomTemporal = valor;
            pasEntrada = 2;
            ultimMissatge = "Participant '" + nomTemporal + "' nou. Escriu la puntuació inicial.";
          }
        } else if (pasEntrada == 2) {
          int punts = int(valor);
          puntuacionsPerJugador.put(nomTemporal, punts);
          ordreParticipants.add(nomTemporal);
          sincronitzarPuntuacions();
          ultimMissatge = "Participant registrat: " + nomTemporal + " amb " + punts + " punts.";
          println(ultimMissatge);
          modeAccio = 0;
          pasEntrada = 0;
        }
      } else if (modeAccio == 3) {
        // 3. Consultar la puntuació d'un participant
        if (puntuacionsPerJugador.containsKey(valor)) {
          int punts = puntuacionsPerJugador.get(valor);
          ultimMissatge = "La puntuació de " + valor + " és: " + punts + " punts.";
        } else {
          ultimMissatge = "No s'ha trobat cap participant amb el nom '" + valor + "'.";
        }
        println(ultimMissatge);
        modeAccio = 0;
        pasEntrada = 0;
      } else if (modeAccio == 7) {
        // 7. Actualitzar la puntuació d'un participant
        if (pasEntrada == 1) {
          if (!puntuacionsPerJugador.containsKey(valor)) {
            ultimMissatge = "Error: el participant '" + valor + "' no existeix al torneig.";
            println(ultimMissatge);
            modeAccio = 0;
            pasEntrada = 0;
          } else {
            nomTemporal = valor;
            pasEntrada = 2;
            ultimMissatge = "Puntuació actual de " + nomTemporal + ": " + puntuacionsPerJugador.get(nomTemporal) + ". Escriu la nova puntuació.";
          }
        } else if (pasEntrada == 2) {
          int novaPuntuacio = int(valor);
          puntuacionsPerJugador.put(nomTemporal, novaPuntuacio);
          sincronitzarPuntuacions();
          ultimMissatge = "S'ha actualitzat la puntuació de " + nomTemporal + " a " + novaPuntuacio + " punts.";
          println(ultimMissatge);
          modeAccio = 0;
          pasEntrada = 0;
        }
      }
      return;
    } else if (key == BACKSPACE) {
      if (textEntrada.length() > 0) {
        textEntrada = textEntrada.substring(0, textEntrada.length() - 1);
      }
      return;
    } else if (key == ESC) {
      modeAccio = 0;
      pasEntrada = 0;
      textEntrada = "";
      ultimMissatge = "Operació cancel·lada.";
      key = 0;
      return;
    } else if (key != CODED && key >= 32) {
      textEntrada += key;
      return;
    }
  }

  if (key == '1' || key == '2') {
    modeAccio = 1;
    pasEntrada = 1;
    textEntrada = "";
    ultimMissatge = "Registrar participant (sense duplicats) -> escriu el nom i prem ENTER.";
  } else if (key == '3') {
    modeAccio = 3;
    pasEntrada = 1;
    textEntrada = "";
    ultimMissatge = "Consultar puntuació -> escriu el nom del participant i prem ENTER.";
  } else if (key == '4') {
    mostrarTotsParticipantsConsola();
    ultimMissatge = "Llistat complet de participants mostrat per consola.";
  } else if (key == '5') {
    println("--- PUNTUACIONS DIFERENTS (HashSet) ---");
    println(puntuacionsDiferents);
    ultimMissatge = "Puntuacions diferents (" + puntuacionsDiferents.size() + "): " + puntuacionsDiferents;
  } else if (key == '6') {
    println("--- PUNTUACIONS ORDENADES (TreeSet) ---");
    println(puntuacionsOrdenades);
    ultimMissatge = "Puntuacions ordenades: " + puntuacionsOrdenades;
  } else if (key == '7') {
    modeAccio = 7;
    pasEntrada = 1;
    textEntrada = "";
    ultimMissatge = "Actualitzar puntuació -> escriu el nom del participant i prem ENTER.";
  } else if (key == '0') {
    ultimMissatge = "Eixint del gestor del torneig...";
