import processing.core.PApplet;
import processing.core.PVector;

class Particula {
  PVector posicio;
  PVector direccio;
  PVector velocitat;
  float   velocitatEscalar;
  float   profunditat;
  int     llarg;
  int     pinta;
}
