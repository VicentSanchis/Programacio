public class Gota extends Particula {
  
}
